const db = require("./database");


// ==============================
// TABELA DE USUÁRIOS
// ==============================

db.exec(`

    CREATE TABLE IF NOT EXISTS usuarios (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        nome TEXT NOT NULL,

        email TEXT NOT NULL UNIQUE,

        senha TEXT NOT NULL

    );

`);


// ==============================
// TABELA DE ALUNOS
// ==============================

db.exec(`

    CREATE TABLE IF NOT EXISTS alunos (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        nome TEXT NOT NULL,

        rm TEXT NOT NULL UNIQUE,

        sala TEXT NOT NULL,

        turno TEXT NOT NULL,

        foto TEXT

    );

`);


// ==============================
// TABELA DE PRESENÇAS
// ==============================

db.exec(`

    CREATE TABLE IF NOT EXISTS presencas (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        aluno_id INTEGER NOT NULL,

        data TEXT NOT NULL,

        horario_entrada TEXT,

        horario_saida TEXT,

        status TEXT NOT NULL,

        FOREIGN KEY (aluno_id)
            REFERENCES alunos(id)

    );

`);

console.log(
    "Tabelas do banco criadas com sucesso."
);