const express = require("express");

const path = require("path");

const cors = require("cors");

const db = require("./database/database");

const alunosRoutes =
    require("./routes/alunos");

const presencasRoutes =
    require("./routes/presencas");

const usuariosRoutes =
    require("./routes/usuarios");

const configuracoesRoutes =
    require("./routes/configuracoes");

const app = express();

const PORT = 3000;


// ==============================
// CONFIGURAÇÕES
// ==============================

app.use(express.json());

app.use(cors());

app.use(express.static(path.join(__dirname, "../frontend")));
// ==============================
// ROTAS
// ==============================

app.use("/alunos", alunosRoutes);

app.use("/presencas", presencasRoutes);

app.use("/usuarios", usuariosRoutes);

app.use("/configuracoes", configuracoesRoutes);

// ==============================
// ROTA PRINCIPAL
// ==============================

app.get("/", function(req, res){

    res.sendFile(
        path.join(
            __dirname,
            "../frontend/index.html"
        )
    );

});


// ==============================
// INICIAR SERVIDOR
// ==============================

app.listen(PORT, function(){

    console.log(
        `Servidor rodando em http://localhost:${PORT}`
    );

});