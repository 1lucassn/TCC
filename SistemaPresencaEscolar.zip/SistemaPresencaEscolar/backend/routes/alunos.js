const express = require("express");

const db = require("../database/database");

const router = express.Router();


// ==============================
// LISTAR TODOS OS ALUNOS
// ==============================

router.get("/", function(req, res){

    try{

        const alunos = db.prepare(`

            SELECT *

            FROM alunos

            ORDER BY nome

        `).all();

        res.json(alunos);

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao buscar alunos."

        });

    }

});


// ==============================
// BUSCAR ALUNO PELO RM
// ==============================

router.get("/:rm", function(req, res){

    try{

        const rm = req.params.rm;

        const aluno = db.prepare(`

            SELECT *

            FROM alunos

            WHERE rm = ?

        `).get(rm);

        if(!aluno){

            return res.status(404).json({

                erro:
                    "Aluno não encontrado."

            });

        }

        res.json(aluno);

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao buscar aluno."

        });

    }

});


// ==============================
// CADASTRAR ALUNO
// ==============================

router.post("/", function(req, res){

    try{

        const {
            nome,
            rm,
            sala,
            turno,
            foto
        } = req.body;


        if(
            !nome ||
            !rm ||
            !sala ||
            !turno
        ){

            return res.status(400).json({

                erro:
                    "Nome, RM, sala e turno são obrigatórios."

            });

        }


        const resultado = db.prepare(`

            INSERT INTO alunos (

                nome,
                rm,
                sala,
                turno,
                foto

            )

            VALUES (?, ?, ?, ?, ?)

        `).run(

            nome,
            rm,
            sala,
            turno,
            foto || null

        );


        const alunoCriado = db.prepare(`

            SELECT *

            FROM alunos

            WHERE id = ?

        `).get(resultado.lastInsertRowid);


        res.status(201).json(alunoCriado);

    }catch(error){

        console.error(error);


        if(
            error.message.includes("UNIQUE")
        ){

            return res.status(409).json({

                erro:
                    "Este RM já está cadastrado."

            });

        }


        res.status(500).json({

            erro:
                "Erro ao cadastrar aluno."

        });

    }

});


// ==============================
// EDITAR ALUNO
// ==============================

router.put("/:rm", function(req, res){

    try{

        const rm = req.params.rm;

        const {
            nome,
            novoRm,
            sala,
            turno,
            foto
        } = req.body;


        const aluno = db.prepare(`

            SELECT *

            FROM alunos

            WHERE rm = ?

        `).get(rm);


        if(!aluno){

            return res.status(404).json({

                erro:
                    "Aluno não encontrado."

            });

        }


        db.prepare(`

            UPDATE alunos

            SET

                nome = ?,
                rm = ?,
                sala = ?,
                turno = ?,
                foto = ?

            WHERE rm = ?

        `).run(

            nome ?? aluno.nome,

            novoRm ?? aluno.rm,

            sala ?? aluno.sala,

            turno ?? aluno.turno,

            foto ?? aluno.foto,

            rm

        );


        const alunoAtualizado = db.prepare(`

            SELECT *

            FROM alunos

            WHERE rm = ?

        `).get(
            novoRm ?? aluno.rm
        );


        res.json(alunoAtualizado);

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao atualizar aluno."

        });

    }

});


// ==============================
// EXCLUIR ALUNO
// ==============================

router.delete("/:rm", function(req, res){

    try{

        const rm = req.params.rm;


        const aluno = db.prepare(`

            SELECT *

            FROM alunos

            WHERE rm = ?

        `).get(rm);


        if(!aluno){

            return res.status(404).json({

                erro:
                    "Aluno não encontrado."

            });

        }


        db.prepare(`

            DELETE FROM alunos

            WHERE rm = ?

        `).run(rm);


        res.json({

            mensagem:
                "Aluno excluído com sucesso."

        });

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao excluir aluno."

        });

    }

});


module.exports = router;