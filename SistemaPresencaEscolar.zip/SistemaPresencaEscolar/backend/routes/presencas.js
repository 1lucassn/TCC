const express = require("express");

const db = require("../database/database");

const router = express.Router();


// ==============================
// REGISTRAR PRESENÇA
// ==============================

router.post("/", function(req, res){

    try{

        const {
            rm,
            data,
            horarioEntrada
        } = req.body;


        if(
            !rm ||
            !data ||
            !horarioEntrada
        ){

            return res.status(400).json({

                erro:
                    "RM, data e horário de entrada são obrigatórios."

            });

        }


        const aluno = db.prepare(`

            SELECT *

            FROM alunos

            WHERE rm = ?

        `).get(rm);


        if(!aluno){

            return res.status(404).json({

                erro:
                    "Aluno não encontrado."

            });

        }


        const registroExistente = db.prepare(`

            SELECT *

            FROM presencas

            WHERE aluno_id = ?

            AND data = ?

        `).get(

            aluno.id,
            data

        );


        if(registroExistente){

            return res.status(409).json({

                erro:
                    "A presença deste aluno já foi registrada hoje."

            });

        }


        const resultado = db.prepare(`

            INSERT INTO presencas (

                aluno_id,
                data,
                horario_entrada,
                status

            )

            VALUES (?, ?, ?, ?)

        `).run(

            aluno.id,
            data,
            horarioEntrada,
            "Presente"

        );


        const presenca = db.prepare(`

            SELECT *

            FROM presencas

            WHERE id = ?

        `).get(

            resultado.lastInsertRowid

        );


        res.status(201).json(presenca);

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao registrar presença."

        });

    }

});


// ==============================
// REGISTRAR SAÍDA
// ==============================

router.put("/:id/saida", function(req, res){

    try{

        const id = req.params.id;

        const {
            horarioSaida
        } = req.body;


        if(!horarioSaida){

            return res.status(400).json({

                erro:
                    "O horário de saída é obrigatório."

            });

        }


        const presenca = db.prepare(`

            SELECT *

            FROM presencas

            WHERE id = ?

        `).get(id);


        if(!presenca){

            return res.status(404).json({

                erro:
                    "Registro de presença não encontrado."

            });

        }


        if(presenca.horario_saida){

            return res.status(409).json({

                erro:
                    "A saída deste aluno já foi registrada."

            });

        }


        db.prepare(`

            UPDATE presencas

            SET horario_saida = ?

            WHERE id = ?

        `).run(

            horarioSaida,
            id

        );


        const atualizado = db.prepare(`

            SELECT *

            FROM presencas

            WHERE id = ?

        `).get(id);


        res.json(atualizado);

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao registrar saída."

        });

    }

});

// ==============================
// REGISTRAR AUSÊNCIA
// ==============================

router.post("/ausencia", function(req, res){

    try{

        const {
            rm,
            data
        } = req.body;


        if(!rm || !data){

            return res.status(400).json({

                erro:
                    "RM e data são obrigatórios."

            });

        }


        const aluno = db.prepare(`

            SELECT *

            FROM alunos

            WHERE rm = ?

        `).get(rm);


        if(!aluno){

            return res.status(404).json({

                erro:
                    "Aluno não encontrado."

            });

        }


        const registroExistente = db.prepare(`

            SELECT *

            FROM presencas

            WHERE aluno_id = ?

            AND data = ?

        `).get(

            aluno.id,
            data

        );


        if(registroExistente){

            return res.status(409).json({

                erro:
                    "Já existe um registro para este aluno hoje."

            });

        }


        const resultado = db.prepare(`

            INSERT INTO presencas (

                aluno_id,
                data,
                horario_entrada,
                status

            )

            VALUES (?, ?, ?, ?)

        `).run(

            aluno.id,
            data,
            null,
            "Ausente"

        );


        const ausencia = db.prepare(`

            SELECT *

            FROM presencas

            WHERE id = ?

        `).get(

            resultado.lastInsertRowid

        );


        res.status(201).json(ausencia);


    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao registrar ausência."

        });

    }

});

// ==============================
// HISTÓRICO DE UM ALUNO
// ==============================

router.get("/aluno/:rm", function(req, res){

    try{

        const rm = req.params.rm;


        const aluno = db.prepare(`

            SELECT *

            FROM alunos

            WHERE rm = ?

        `).get(rm);


        if(!aluno){

            return res.status(404).json({

                erro:
                    "Aluno não encontrado."

            });

        }


        const historico = db.prepare(`

            SELECT *

            FROM presencas

            WHERE aluno_id = ?

            ORDER BY data DESC

        `).all(

            aluno.id

        );


        res.json({

            aluno: aluno,

            historico: historico

        });

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao buscar histórico."

        });

    }

});


module.exports = router;