const express = require("express");

const db = require("../database/database");

const router = express.Router();


// ==============================
// CADASTRAR USUÁRIO
// ==============================

router.post("/", function(req, res){

    try{

        const {
            nome,
            email,
            senha
        } = req.body;


        if(
            !nome ||
            !email ||
            !senha
        ){

            return res.status(400).json({

                erro:
                    "Nome, email e senha são obrigatórios."

            });

        }


        const emailNormalizado =
            email.trim().toLowerCase();


        const usuarioExistente = db.prepare(`

            SELECT *

            FROM usuarios

            WHERE email = ?

        `).get(emailNormalizado);


        if(usuarioExistente){

            return res.status(409).json({

                erro:
                    "Este email já está cadastrado."

            });

        }


        const resultado = db.prepare(`

            INSERT INTO usuarios (

                nome,
                email,
                senha

            )

            VALUES (?, ?, ?)

        `).run(

            nome,
            emailNormalizado,
            senha

        );


        const usuario = db.prepare(`

            SELECT

                id,
                nome,
                email

            FROM usuarios

            WHERE id = ?

        `).get(
            resultado.lastInsertRowid
        );


        res.status(201).json(usuario);

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao cadastrar usuário."

        });

    }

});


// ==============================
// LOGIN
// ==============================

router.post("/login", function(req, res){

    try{

        const {
            email,
            senha
        } = req.body;


        if(
            !email ||
            !senha
        ){

            return res.status(400).json({

                erro:
                    "Email e senha são obrigatórios."

            });

        }


        const emailNormalizado =
            email.trim().toLowerCase();


        const usuario = db.prepare(`

            SELECT *

            FROM usuarios

            WHERE email = ?

        `).get(emailNormalizado);


        if(!usuario){

            return res.status(401).json({

                erro:
                    "Usuário não encontrado."

            });

        }


        if(usuario.senha !== senha){

            return res.status(401).json({

                erro:
                    "Senha incorreta."

            });

        }


        res.json({

            mensagem:
                "Login realizado com sucesso.",

            usuario: {

                id: usuario.id,

                nome: usuario.nome,

                email: usuario.email

            }

        });

    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao realizar login."

        });

    }

});

module.exports = router;