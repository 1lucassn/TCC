const express = require("express");

const db = require("../database/database");

const router = express.Router();


// ==============================
// BUSCAR CONFIGURAÇÕES
// ==============================

router.get("/", function(req, res){

    try{

        const configuracoes = db.prepare(`

            SELECT
                id,
                hora_inicio,
                hora_limite_entrada,
                hora_saida,
                hora_saida_sem_falta

            FROM configuracoes

            WHERE id = 1

        `).get();


        if(!configuracoes){

            return res.status(404).json({

                erro:
                    "Configurações não encontradas."

            });

        }


        res.json(configuracoes);


    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao buscar configurações."

        });

    }

});


// ==============================
// SALVAR CONFIGURAÇÕES
// ==============================

router.put("/", function(req, res){

    try{

        const {
            horaInicio,
            horaLimiteEntrada,
            horaSaida,
            horaSaidaSemFalta
        } = req.body;


        if(
            !horaInicio ||
            !horaLimiteEntrada ||
            !horaSaida ||
            !horaSaidaSemFalta
        ){

            return res.status(400).json({

                erro:
                    "Todos os horários são obrigatórios."

            });

        }


        db.prepare(`

            UPDATE configuracoes

            SET
                hora_inicio = ?,
                hora_limite_entrada = ?,
                hora_saida = ?,
                hora_saida_sem_falta = ?

            WHERE id = 1

        `).run(

            horaInicio,
            horaLimiteEntrada,
            horaSaida,
            horaSaidaSemFalta

        );


        const configuracoesAtualizadas =
            db.prepare(`

                SELECT
                    id,
                    hora_inicio,
                    hora_limite_entrada,
                    hora_saida,
                    hora_saida_sem_falta

                FROM configuracoes

                WHERE id = 1

            `).get();


        res.json(
            configuracoesAtualizadas
        );


    }catch(error){

        console.error(error);

        res.status(500).json({

            erro:
                "Erro ao salvar configurações."

        });

    }

});


module.exports = router;