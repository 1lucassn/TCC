const login = document.getElementById("login");
const painel = document.getElementById("painel");


const cadastroAluno = document.getElementById("cadastroAluno");

const menuCadastrar = document.getElementById("menuCadastrar");

const voltarPainel = document.getElementById("voltarPainel");

const calendario = document.getElementById("calendario");
const frequencia = document.getElementById("frequencia");
const configuracoes = document.getElementById("configuracoes");

const menuCalendario = document.getElementById("menuCalendario");
const menuFrequencia = document.getElementById("menuFrequencia");
const menuConfiguracoes = document.getElementById("menuConfiguracoes");
const menuSair = document.getElementById("menuSair");

const nomeAluno = document.getElementById("nomeAluno");
const rmAluno = document.getElementById("rmAluno");
const salaAluno = document.getElementById("salaAluno");
const turnoAluno = document.getElementById("turnoAluno");
const fotoAluno = document.getElementById("fotoAluno");

const btnCadastrarAluno = document.getElementById("btnCadastrarAluno");
const btnLimpar = document.getElementById("btnLimpar");

const telaSala = document.getElementById("telaSala");
const tituloSala = document.getElementById("tituloSala");
const corpoTabela = document.getElementById("corpoTabela");
const voltarSala = document.getElementById("voltarSala");
const cards = document.querySelectorAll(".cardSala");

// ==============================
// CADASTRO DE USUÁRIO
// ==============================

const cadastroUsuario =
document.getElementById("cadastroUsuario");

const btnCadastrarUsuario =
document.getElementById("btnCadastrarUsuario");

const voltarLogin =
document.getElementById("voltarLogin");

const salvarUsuario =
document.getElementById("salvarUsuario");

const limparUsuario =
document.getElementById("limparUsuario");

const nomeUsuario =
document.getElementById("nomeUsuario");

const emailUsuario =
document.getElementById("emailUsuario");

const senhaUsuario =
document.getElementById("senhaUsuario");

const confirmarSenha =
document.getElementById("confirmarSenha");

const emailLogin = document.getElementById("emailLogin");

const senhaLogin = document.getElementById("senhaLogin");

const btnEntrar = document.getElementById("btnEntrar");

const dataPesquisa =
document.getElementById("dataPesquisa");

const btnPesquisarData =
document.getElementById("btnPesquisarData");

const resultadoCalendario =
document.getElementById("resultadoCalendario");

const btnCalcularFrequencia =
document.getElementById("btnCalcularFrequencia");

const resultadoFrequencia =
document.getElementById("resultadoFrequencia");

const voltarCalendario =
document.getElementById("voltarCalendario");

const mesAnterior =
document.getElementById("mesAnterior");

const mesProximo =
document.getElementById("mesProximo");

const mesAtual =
document.getElementById("mesAtual");

const calendarioDias =
document.getElementById("calendarioDias");

const tituloDiaCalendario =
document.getElementById("tituloDiaCalendario");

const resumoDiaCalendario =
document.getElementById("resumoDiaCalendario");

let dataCalendario = new Date();

const voltarFrequencia =
document.getElementById("voltarFrequencia");

const alunoFrequencia =
document.getElementById("alunoFrequencia");

const mesFrequencia =
document.getElementById("mesFrequencia");

const calcularFrequencia =
document.getElementById("calcularFrequencia");

const nomeAlunoFrequencia =
document.getElementById("nomeAlunoFrequencia");

const totalPresencas =
document.getElementById("totalPresencas");

const totalFaltas =
document.getElementById("totalFaltas");

const totalDias =
document.getElementById("totalDias");

const porcentagemFrequencia =
document.getElementById("porcentagemFrequencia");

const tabelaFrequencia =
document.getElementById("tabelaFrequencia");

const voltarConfiguracoes =
document.getElementById(
    "voltarConfiguracoes"
);

const horaInicio =
document.getElementById(
    "horaInicio"
);

const horaLimiteEntrada =
document.getElementById(
    "horaLimiteEntrada"
);

const horaSaida =
document.getElementById(
    "horaSaida"
);

const horaSaidaSemFalta =
document.getElementById(
    "horaSaidaSemFalta"
);

const salvarConfiguracoes =
document.getElementById(
    "salvarConfiguracoes"
);

const limparConfiguracoes =
document.getElementById(
    "limparConfiguracoes"
);

btnEntrar.addEventListener("click", async function(){

    console.log("NOVO LOGIN FOI EXECUTADO");
    
    const email =
        emailLogin.value
        .trim()
        .toLowerCase();

    const senha =
        senhaLogin.value;


    if(email === ""){

        alert("Digite o email.");

        return;

    }


    if(senha === ""){

        alert("Digite a senha.");

        return;

    }


    try{

        const resposta =
            await fetch(
                "http://localhost:3000/usuarios/login",
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify({

                        email: email,

                        senha: senha

                    })

                }
            );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(
                dados.erro ||
                "Não foi possível realizar o login."
            );

            return;

        }


        // ==============================
        // LOGIN REALIZADO
        // ==============================

        login.style.display =
            "none";

        painel.style.display =
            "block";


        await carregarAlunosDoBackend();


        emailLogin.value = "";

        senhaLogin.value = "";


    }catch(error){

        console.error(error);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

});

// ==============================
// BANCO DE DADOS TEMPORÁRIO
// ==============================

let alunos = [];

async function carregarAlunosDoBackend() {

    try {

        const resposta = await fetch(
            "http://localhost:3000/alunos"
        );


        if (!resposta.ok) {

            throw new Error(
                "Erro ao buscar alunos."
            );

        }


        const dados =
            await resposta.json();


        alunos = dados.map(function(aluno) {

            return {

                ...aluno,

                presente: false,

                horarioEntrada: "",

                data: "",

                historico: []

            };

        });


        // ==============================
        // CARREGAR HISTÓRICO
        // ==============================

        for(
            const aluno of alunos
        ){

            try{

                const respostaHistorico =
                    await fetch(

                        "http://localhost:3000/presencas/aluno/" +
                        aluno.rm

                    );


                if(
                    !respostaHistorico.ok
                ){

                    continue;

                }


                const dadosHistorico =
                    await respostaHistorico.json();


                aluno.historico =
                    dadosHistorico.historico.map(
                        function(registro){

                            return {

                                id:
                                    registro.id,

                                data:
                                    registro.data,

                                status:
                                    registro.status,

                                horario:
                                    registro.horario_entrada,

                                horarioSaida:
                                    registro.horario_saida ||
                                    "",

                                aulas:
    registro.horario_entrada
        ? criarAulasDoDia(
            registro.horario_entrada
        )
        : []

                            };

                        }
                    );


                // ==============================
                // VERIFICAR PRESENÇA DE HOJE
                // ==============================

                const hoje =
                    obterDataAtual();


                const registroHoje =
                    aluno.historico.find(
                        function(registro){

                            return (
                                registro.data === hoje
                            );

                        }
                    );


                if(
                    registroHoje &&
                    registroHoje.status === "Presente"
                ){

                    aluno.presente = true;

                    aluno.horarioEntrada =
                        registroHoje.horario;

                }


            }catch(erroHistorico){

                console.error(

                    "Erro ao carregar histórico do aluno " +
                    aluno.rm,

                    erroHistorico

                );

            }

        }


        atualizarCards();


        console.log(
            "Alunos e históricos carregados:",
            alunos
        );


    }catch(erro){

        console.error(
            "Erro ao carregar alunos:",
            erro
        );

    }

}

menuCalendario.addEventListener("click", function () {

    esconderTodasAsTelas();

    calendario.style.display = "block";

    mostrarCalendario();
});

menuFrequencia.addEventListener("click", function () {

    esconderTodasAsTelas();

    frequencia.style.display = "block";

     carregarAlunosFrequencia();
});

menuConfiguracoes.addEventListener("click", function () {

    esconderTodasAsTelas();

    configuracoes.style.display = "block";

    carregarConfiguracoes();

});

menuCadastrar.addEventListener("click", function () {

    esconderTodasAsTelas();

    cadastroAluno.style.display = "block";

});

voltarPainel.addEventListener("click", function () {

    esconderTodasAsTelas();

    painel.style.display = "block";

});

const botoesVoltar = document.querySelectorAll(".voltar");

botoesVoltar.forEach(function (botao) {

    botao.addEventListener("click", function () {

        esconderTodasAsTelas();

        painel.style.display = "block";

    });

});

menuSair.addEventListener("click", function () {

    esconderTodasAsTelas();

    login.style.display = "block";

});

// ====================================
// LIMPAR CAMPOS
// ====================================

function limparCampos() {

    nomeAluno.value = "";
    rmAluno.value = "";
    salaAluno.selectedIndex = 0;
    turnoAluno.selectedIndex = 0;
    fotoAluno.value = "";

}

// ====================================
// CADASTRAR ALUNO
// ====================================

btnCadastrarAluno.addEventListener("click", async function () {

    const nome = nomeAluno.value.trim();
    const rm = rmAluno.value.trim();

    if (nome === "") {

        alert("Digite o nome do aluno.");

        return;

    }

    if (rm === "") {

        alert("Digite o RM.");

        return;

    }

    if (rm.length != 5) {

        alert("O RM deve possuir exatamente 5 números.");

        return;

    }

    if (isNaN(rm)) {

        alert("O RM deve conter apenas números.");

        return;

    }


    const alunoExistente = alunos.find(function (aluno) {

        return aluno.rm === rm;

    });

    if (alunoExistente) {

        alert("Já existe um aluno com esse RM.");

        return;

    }


    const aluno = {

        nome: nome,

        rm: rm,

        sala: salaAluno.value,

        turno: turnoAluno.value,

        foto: fotoAluno.files[0]
            ? fotoAluno.files[0].name
            : ""

    };


    try {

        const resposta = await fetch(
            "http://localhost:3000/alunos",
            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify(aluno)

            }
        );


        const dados = await resposta.json();


        if (!resposta.ok) {

            alert(
                dados.erro ||
                "Erro ao cadastrar aluno."
            );

            return;

        }


        const alunoCadastrado = {

            ...dados,

            presente: false,

            horarioEntrada: "",

            data: "",

            historico: []

        };


        alunos.push(alunoCadastrado);


        atualizarCards();


        console.log(
            "Aluno cadastrado no backend:",
            alunoCadastrado
        );


        alert(
            "Aluno cadastrado com sucesso!"
        );


        limparCampos();


    } catch (erro) {

        console.error(erro);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

});

// ====================================
// BOTÃO LIMPAR
// ====================================

btnLimpar.addEventListener("click", function () {

    limparCampos();

});

// Permite somente números no RM

rmAluno.addEventListener("input", function () {

    this.value = this.value.replace(/\D/g, "");

});

// Permite apenas letras e espaços

nomeAluno.addEventListener("input", function () {

    this.value = this.value.replace(/[^A-Za-zÀ-ÿ ]/g, "");

});

function atualizarCards(){

    const turnoSelecionado = turno.value;

    cards.forEach(function(card){

        const nomeSala = card.querySelector("h3").textContent;

        const alunosDaSala = alunos.filter(function(aluno){

            return aluno.sala === nomeSala &&
                   aluno.turno === turnoSelecionado;

        });

        const presentes = alunosDaSala.filter(function(aluno){

            return aluno.presente;

        });

        const aguardando = alunosDaSala.filter(function(aluno){

            return !aluno.presente;

        });

        card.querySelectorAll("p")[0].innerHTML =
            "Alunos: <strong>" + alunosDaSala.length + "</strong>";

        card.querySelectorAll("p")[1].innerHTML =
            "Presentes: <strong>" + presentes.length +
            "</strong> | Aguardando: <strong>" +
            aguardando.length + "</strong>";

    });

}

cards.forEach(function (card) {

    card.addEventListener("click", function () {

        esconderTodasAsTelas();

        telaSala.style.display = "block";

        const sala = card.querySelector("h3").textContent;

        tituloSala.textContent = sala;

        corpoTabela.innerHTML = "";

        alunos.forEach(function (aluno) {

            if (aluno.sala === sala && aluno.turno === turno.value) {

                corpoTabela.innerHTML += `

<tr>

    <td>${aluno.nome}</td>

    <td>${aluno.rm}</td>

    <td>${aluno.turno}</td>

<td id="status-${aluno.rm}">

    ${(() => {

        const registroHoje =
            aluno.historico.find(function(registro){

                return registro.data === obterDataAtual();

            });

        if(
            registroHoje &&
            registroHoje.horarioSaida
        ){

            return "🔵 Saiu";

        }

        if(
            registroHoje &&
            registroHoje.status === "Presente"
        ){

            return "🟢 Presente";

        }

        return "🟡 Aguardando";

    })()}

</td>

<td id="hora-${aluno.rm}">
    ${aluno.horarioEntrada || "--:--"}
</td>

    <button onclick="marcarPresenca('${aluno.rm}')">

        Presença

    </button>

    <button onclick="registrarSaida('${aluno.rm}')">

    Saída

    </button>

    <button onclick="editarAluno('${aluno.rm}')">

        Editar

    </button>

    <button onclick="excluirAluno('${aluno.rm}')">

        Excluir

    </button>

    <button onclick="verHistorico('${aluno.rm}')">Histórico</button>


</td>

</tr>

`;

            }

        });

        mostrarAulas();

    });

});

function esconderTodasAsTelas() {

    painel.style.display = "none";
    cadastroAluno.style.display = "none";
    calendario.style.display = "none";
    frequencia.style.display = "none";
    configuracoes.style.display = "none";
    telaSala.style.display = "none";

}

voltarSala.addEventListener("click", function () {

    esconderTodasAsTelas();

    painel.style.display = "block";

});

async function marcarPresenca(rm){

    const aluno = alunos.find(function(a){

        return a.rm === rm;

    });

    if(!aluno){

        return;

    }


    const agora = new Date();


    const hora =
        agora.getHours()
        .toString()
        .padStart(2,"0");


    const minuto =
        agora.getMinutes()
        .toString()
        .padStart(2,"0");


    const horarioAtual =
        hora + ":" + minuto;


    const dataAtual =
        obterDataAtual();


    const registroHoje =
        aluno.historico.find(function(registro){

            return registro.data === dataAtual;

        });


    if(
        registroHoje &&
        registroHoje.status === "Presente"
    ){

        alert(
            "A presença deste aluno já foi registrada hoje."
        );

        return;

    }


    try{

        const resposta = await fetch(

            "http://localhost:3000/presencas",

            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    rm: rm,

                    data: dataAtual,

                    horarioEntrada:
                        horarioAtual

                })

            }

        );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(

                dados.erro ||
                "Erro ao registrar presença."

            );

            return;

        }


        const novoRegistro = {

            id: dados.id,

            data: dados.data,

            status: dados.status,

            horario: dados.horario_entrada,

            horarioSaida:
                dados.horario_saida || "",

            aulas:
                criarAulasDoDia(
                    dados.horario_entrada
                )

        };


        aluno.presente = true;

        aluno.horarioEntrada =
            dados.horario_entrada;


        aluno.historico.push(
            novoRegistro
        );


        const elementoStatus =
            document.getElementById(
                "status-" + rm
            );


        const elementoHora =
            document.getElementById(
                "hora-" + rm
            );


        if(elementoStatus){

            elementoStatus.innerHTML =
                "🟢 Presente";

        }


        if(elementoHora){

            elementoHora.innerHTML =
                dados.horario_entrada;

        }


        atualizarCards();


        alert(
            "Presença registrada com sucesso!"
        );


    }catch(erro){

        console.error(erro);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

}

turno.addEventListener("change", function(){

    atualizarCards();

});

async function excluirAluno(rm){

    const confirmar =
        confirm(
            "Deseja realmente excluir este aluno?"
        );

    if(!confirmar){

        return;

    }


    try{

        const resposta = await fetch(

            "http://localhost:3000/alunos/" + rm,

            {

                method: "DELETE"

            }

        );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(

                dados.erro ||
                "Erro ao excluir aluno."

            );

            return;

        }


        alunos = alunos.filter(
            function(aluno){

                return aluno.rm !== rm;

            }
        );


        atualizarCards();


        corpoTabela.innerHTML = "";


        const salaAtual =
            tituloSala.textContent;


        alunos.forEach(
            function(aluno){

                if(

                    aluno.sala === salaAtual &&

                    aluno.turno === turno.value

                ){

                    corpoTabela.innerHTML += `

                    <tr>

                        <td>${aluno.nome}</td>

                        <td>${aluno.rm}</td>

                        <td>${aluno.turno}</td>

                        <td id="status-${aluno.rm}">

                            ${
                                aluno.presente
                                ? "🟢 Presente"
                                : "🟡 Aguardando"
                            }

                        </td>

                        <td id="hora-${aluno.rm}">

                            ${
                                aluno.horarioEntrada ||
                                "--:--"
                            }

                        </td>

                        <td>

                            <button
                                onclick="marcarPresenca('${aluno.rm}')"
                            >
                                Presença
                            </button>

                            <button
                                onclick="registrarSaida('${aluno.rm}')"
                            >
                                Saída
                            </button>

                            <button
                                onclick="editarAluno('${aluno.rm}')"
                            >
                                Editar
                            </button>

                            <button
                                onclick="excluirAluno('${aluno.rm}')"
                            >
                                Excluir
                            </button>

                            <button
                                onclick="verHistorico('${aluno.rm}')"
                            >
                                Histórico
                            </button>

                        </td>

                    </tr>

                    `;

                }

            }
        );


        alert(
            "Aluno excluído com sucesso."
        );


    }catch(erro){

        console.error(erro);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

}

async function editarAluno(rm){

    const aluno = alunos.find(function(a){

        return a.rm === rm;

    });

    if(!aluno){

        return;

    }


    const novoNome =
        prompt("Novo nome:", aluno.nome);

    if(novoNome == null){

        return;

    }


    const novaSala =
        prompt("Nova sala:", aluno.sala);


    const novoTurno =
        prompt("Novo turno:", aluno.turno);


    const dadosAtualizados = {

        nome: novoNome,

        sala:
            novaSala != null
                ? novaSala
                : aluno.sala,

        turno:
            novoTurno != null
                ? novoTurno
                : aluno.turno

    };


    try{

        const resposta = await fetch(

            "http://localhost:3000/alunos/" + rm,

            {

                method: "PUT",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body:
                    JSON.stringify(
                        dadosAtualizados
                    )

            }

        );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(

                dados.erro ||
                "Erro ao atualizar aluno."

            );

            return;

        }


        aluno.nome =
            dados.nome;

        aluno.sala =
            dados.sala;

        aluno.turno =
            dados.turno;


        atualizarCards();


        alert(
            "Aluno atualizado com sucesso."
        );


    }catch(erro){

        console.error(erro);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

}

async function verHistorico(rm){

    const aluno = alunos.find(function(a){

        return a.rm === rm;

    });

    if(!aluno){

        return;

    }


    try{

        const resposta = await fetch(

            "http://localhost:3000/presencas/aluno/" +
            rm

        );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(

                dados.erro ||
                "Erro ao buscar histórico."

            );

            return;

        }


        let texto = "";


        dados.historico.forEach(
            function(item){

                texto +=
                    "\n📅 " +
                    item.data +

                    "\nStatus: " +
                    item.status;


                if(item.horario_entrada){

                    texto +=
                        "\nHorário de entrada: " +
                        item.horario_entrada;

                }


                if(item.horario_saida){

                    texto +=
                        "\nHorário de saída: " +
                        item.horario_saida;

                }


                // ==============================
                // AULAS
                // ==============================

                const registroLocal =
                    aluno.historico.find(
                        function(registro){

                            return (
                                registro.data ===
                                item.data
                            );

                        }
                    );


                if(
                    registroLocal &&
                    registroLocal.aulas
                ){

                    texto += "\n\nAulas:";


                    registroLocal.aulas.forEach(
                        function(aula){

                            let simbolo = "🟢";


                            if(
                                aula.status ===
                                "Ausente"
                            ){

                                simbolo = "🔴";

                            }


                            texto +=
                                "\n" +
                                simbolo +
                                " " +
                                aula.aula +
                                "ª aula (" +
                                aula.inicio +
                                " - " +
                                aula.fim +
                                "): " +
                                aula.status;

                        }
                    );

                }


                texto +=
                    "\n\n--------------------\n";

            }
        );


        if(texto === ""){

            texto =
                "\nNenhum registro encontrado.";

        }


        alert(

            "Histórico de " +
            aluno.nome +
            "\n" +
            texto

        );


    }catch(erro){

        console.error(erro);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }


}

atualizarCards();

// =======================================
// ABRIR CADASTRO DE USUÁRIO
// =======================================

btnCadastrarUsuario.addEventListener("click", function(){

    login.style.display = "none";

    cadastroUsuario.style.display = "block";

});

// =======================================
// VOLTAR PARA LOGIN
// =======================================

voltarLogin.addEventListener("click", function(){

    cadastroUsuario.style.display = "none";

    login.style.display = "block";

});

// =======================================
// LIMPAR CAMPOS
// =======================================

limparUsuario.addEventListener("click", function(){

    nomeUsuario.value = "";

    emailUsuario.value = "";

    senhaUsuario.value = "";

    confirmarSenha.value = "";

});

// ======================================
// CADASTRAR USUÁRIO
// ======================================

salvarUsuario.addEventListener("click", async function(){

    const nome = nomeUsuario.value.trim();

    const email = emailUsuario.value.trim().toLowerCase();

    const senha = senhaUsuario.value;

    const confirmar = confirmarSenha.value;

    if(nome === ""){

        alert("Digite o nome.");

        return;

    }

    if(email === ""){

        alert("Digite o email.");

        return;

    }

    if(senha === ""){

        alert("Digite a senha.");

        return;

    }

    if(senha !== confirmar){

        alert("As senhas não coincidem.");

        return;

    }

  try{

    const resposta =
        await fetch(
            "http://localhost:3000/usuarios",
            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    nome: nome,

                    email: email,

                    senha: senha

                })

            }
        );


    const dados =
        await resposta.json();


    if(!resposta.ok){

        alert(
            dados.erro ||
            "Não foi possível cadastrar o usuário."
        );

        return;

    }


    alert(
        "Usuário cadastrado com sucesso!"
    );


    nomeUsuario.value = "";

    emailUsuario.value = "";

    senhaUsuario.value = "";

    confirmarSenha.value = "";


    cadastroUsuario.style.display =
        "none";

    login.style.display =
        "block";


}catch(error){

    console.error(error);

    alert(
        "Não foi possível conectar ao servidor."
    );

}

});

// ==============================
// FREQUÊNCIA MENSAL
// ==============================

function carregarAlunosFrequencia(){

    alunoFrequencia.innerHTML = "";

    const opcaoInicial =
        document.createElement("option");

    opcaoInicial.value = "";

    opcaoInicial.innerHTML =
        "Selecione um aluno";

    alunoFrequencia.appendChild(
        opcaoInicial
    );

    alunos.forEach(function(aluno){

        const opcao =
            document.createElement("option");

        opcao.value = aluno.rm;

        opcao.innerHTML =
            aluno.nome +
            " - RM " +
            aluno.rm;

        alunoFrequencia.appendChild(
            opcao
        );

    });

}


// ==============================
// CALCULAR FREQUÊNCIA
// ==============================

async function calcularFrequenciaAluno(){

    const rm =
        alunoFrequencia.value;


    const mesSelecionado =
        mesFrequencia.value;


    if(rm === ""){

        alert(
            "Selecione um aluno."
        );

        return;

    }


    if(mesSelecionado === ""){

        alert(
            "Selecione um mês."
        );

        return;

    }


    const aluno =
        alunos.find(function(a){

            return a.rm === rm;

        });


    if(!aluno){

        alert(
            "Aluno não encontrado."
        );

        return;

    }


    try{

        const resposta =
            await fetch(

                "http://localhost:3000/presencas/aluno/" +
                rm

            );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(

                dados.erro ||
                "Erro ao buscar frequência."

            );

            return;

        }


        const registrosDoMes =
            dados.historico.filter(
                function(registro){

                    const partes =
                        registro.data.split("/");


                    const mes =
                        partes[1];


                    const ano =
                        partes[2];


                    const mesAno =
                        ano + "-" + mes;


                    return (
                        mesAno ===
                        mesSelecionado
                    );

                }
            );


        let presencas = 0;

        let faltas = 0;


        registrosDoMes.forEach(
            function(registro){

                if(
                    registro.status ===
                    "Presente"
                ){

                    presencas++;

                }


                if(
                    registro.status ===
                    "Ausente"
                ){

                    faltas++;

                }

            }
        );


        const diasRegistrados =
            presencas + faltas;


        let porcentagem = 0;


        if(diasRegistrados > 0){

            porcentagem =
                (
                    presencas /
                    diasRegistrados
                ) * 100;

        }


        nomeAlunoFrequencia.innerHTML =
            aluno.nome;


        totalPresencas.innerHTML =
            presencas;


        totalFaltas.innerHTML =
            faltas;


        totalDias.innerHTML =
            diasRegistrados;


        porcentagemFrequencia.innerHTML =
            porcentagem.toFixed(1) + "%";


        mostrarTabelaFrequencia(
            registrosDoMes
        );


    }catch(erro){

        console.error(erro);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

}


// ==============================
// MOSTRAR TABELA
// ==============================

function mostrarTabelaFrequencia(
    registros
){

    tabelaFrequencia.innerHTML = "";


    if(registros.length === 0){

        tabelaFrequencia.innerHTML = `

            <tr>

                <td colspan="4">

                    Nenhum registro encontrado.

                </td>

            </tr>

        `;

        return;

    }


    registros.forEach(
        function(registro){

            const linha =
                document.createElement("tr");


            let status =
                "🔴 Ausente";


            if(
                registro.status ===
                "Presente"
            ){

                status =
                    "🟢 Presente";

            }


            linha.innerHTML = `

                <td>
                    ${registro.data}
                </td>

                <td>
                    ${status}
                </td>

                <td>
                    ${registro.horario || "--:--"}
                </td>

                <td>
                    ${registro.horarioSaida || "--:--"}
                </td>

            `;


            tabelaFrequencia.appendChild(
                linha
            );

        }
    );

}


// ==============================
// BOTÃO CALCULAR
// ==============================

calcularFrequencia.addEventListener(
    "click",
    function(){

        calcularFrequenciaAluno();

    }
);


async function atualizarStatusPresenca(){

    const agora = new Date();

    const hora = agora.getHours();

    const minuto = agora.getMinutes();

    const minutosAtuais =
        (hora * 60) + minuto;


    // Limite de entrada: 07:35
    const limiteEntrada =
        (7 * 60) + 35;


    const dataHoje =
        obterDataAtual();


    for(const aluno of alunos){

        const elementoStatus =
            document.getElementById(
                "status-" + aluno.rm
            );


        if(!elementoStatus){

            continue;

        }


        // ==============================
        // VERIFICA REGISTRO DE HOJE
        // ==============================

        const registroHoje =
            aluno.historico.find(
                function(registro){

                    return (
                        registro.data ===
                        dataHoje
                    );

                }
            );


        // ==============================
        // JÁ POSSUI REGISTRO
        // ==============================

        if(registroHoje){

            if(
                registroHoje.status ===
                "Presente"
            ){

                elementoStatus.innerHTML =
                    "🟢 Presente";

            }


            if(
                registroHoje.status ===
                "Ausente"
            ){

                elementoStatus.innerHTML =
                    "🔴 Ausente";

            }


            continue;

        }


        // ==============================
        // ANTES DO LIMITE
        // ==============================

        if(
            minutosAtuais <
            limiteEntrada
        ){

            elementoStatus.innerHTML =
                "🟡 Aguardando";

            continue;

        }


        // ==============================
        // DEPOIS DO LIMITE
        // REGISTRAR AUSÊNCIA NO BANCO
        // ==============================

        try{

            const resposta =
                await fetch(

                    "http://localhost:3000/presencas/ausencia",

                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body: JSON.stringify({

                            rm: aluno.rm,

                            data: dataHoje

                        })

                    }

                );


            const dados =
                await resposta.json();


            if(!resposta.ok){

                console.error(
                    "Erro ao registrar ausência:",
                    dados.erro
                );

                continue;

            }


            // ==============================
            // ADICIONA AO HISTÓRICO LOCAL
            // ==============================

            aluno.historico.push({

                id:
                    dados.id,

                data:
                    dados.data,

                status:
                    dados.status,

                horario:
                    dados.horario_entrada || "",

                horarioSaida:
                    dados.horario_saida || "",

                aulas: []

            });


            elementoStatus.innerHTML =
                "🔴 Ausente";


        }catch(erro){

            console.error(
                "Erro ao conectar ao servidor:",
                erro
            );

        }

    }

}

setInterval(function(){

    atualizarStatusPresenca();

}, 60000);

atualizarStatusPresenca();

function obterDataAtual(){

    const hoje = new Date();

    return (
        hoje.getDate().toString().padStart(2, "0") +
        "/" +
        (hoje.getMonth() + 1).toString().padStart(2, "0") +
        "/" +
        hoje.getFullYear()
    );

}

const aulasDoDia =
document.getElementById("aulasDoDia");

const aulas = [

    {
        numero: 1,
        inicio: "07:30",
        fim: "08:20"
    },

    {
        numero: 2,
        inicio: "08:20",
        fim: "09:10"
    },

    {
        numero: 3,
        inicio: "09:10",
        fim: "10:00"
    },

    {
        numero: 4,
        inicio: "10:20",
        fim: "11:10"
    },

    {
        numero: 5,
        inicio: "11:10",
        fim: "12:00"
    },

    {
        numero: 6,
        inicio: "13:00",
        fim: "13:50"
    },

    {
        numero: 7,
        inicio: "13:50",
        fim: "14:40"
    },

    {
        numero: 8,
        inicio: "14:40",
        fim: "15:30"
    }

];

function horarioParaMinutos(horario){

    const partes = horario.split(":");

    const horas = Number(partes[0]);

    const minutos = Number(partes[1]);

    return (horas * 60) + minutos;

}

function criarAulasDoDia(horarioEntrada){

    const entrada =
        horarioParaMinutos(horarioEntrada);

    const resultado = [];

    aulas.forEach(function(aula){

        const inicio =
            horarioParaMinutos(aula.inicio);

        const fim =
            horarioParaMinutos(aula.fim);

        let status = "Presente";

        /*
        Se o aluno chegou depois do fim
        daquela aula, ele perdeu a aula.
        */

        if(entrada >= fim){

            status = "Ausente";

        }

        resultado.push({

            aula: aula.numero,

            inicio: aula.inicio,

            fim: aula.fim,

            status: status

        });

    });

    return resultado;

}

async function registrarSaida(rm){

    const aluno = alunos.find(function(a){

        return a.rm === rm;

    });

    if(!aluno){

        return;

    }


    const dataAtual =
        obterDataAtual();


    const registroHoje =
        aluno.historico.find(function(registro){

            return registro.data === dataAtual;

        });


    if(!registroHoje){

        alert(
            "Este aluno ainda não possui uma entrada registrada hoje."
        );

        return;

    }


    if(registroHoje.status !== "Presente"){

        alert(
            "Este aluno não está marcado como presente."
        );

        return;

    }


    if(registroHoje.horarioSaida){

        alert(
            "A saída deste aluno já foi registrada hoje."
        );

        return;

    }


    if(!registroHoje.id){

        alert(
            "Não foi possível encontrar o registro de presença no banco."
        );

        console.error(
            "Registro sem ID:",
            registroHoje
        );

        return;

    }


    const agora = new Date();


    const hora =
        agora.getHours()
        .toString()
        .padStart(2, "0");


    const minuto =
        agora.getMinutes()
        .toString()
        .padStart(2, "0");


    const horarioSaida =
        hora + ":" + minuto;


    try{

        const resposta = await fetch(

            "http://localhost:3000/presencas/" +
            registroHoje.id +
            "/saida",

            {

                method: "PUT",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    horarioSaida:
                        horarioSaida

                })

            }

        );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(

                dados.erro ||
                "Erro ao registrar saída."

            );

            return;

        }


        // ==============================
        // ATUALIZA O REGISTRO LOCAL
        // ==============================

        registroHoje.horarioSaida =
            dados.horario_saida;


        atualizarAulasDepoisDaSaida(

            registroHoje,

            dados.horario_saida

        );


        // ==============================
        // ATUALIZA STATUS NA TABELA
        // ==============================

        const statusAluno =
            document.getElementById(
                "status-" + rm
            );


        if(statusAluno){

            statusAluno.innerHTML =
                "🔵 Saiu";

        }


        // ==============================
        // ATUALIZA HORÁRIOS
        // ==============================

        const horaAluno =
            document.getElementById(
                "hora-" + rm
            );


        if(horaAluno){

            horaAluno.innerHTML = `

                Entrada:
                ${registroHoje.horario || "--:--"}

                <br>

                Saída:
                ${registroHoje.horarioSaida || "--:--"}

            `;

        }


        alert(
            "Saída registrada às " +
            dados.horario_saida
        );


    }catch(erro){

        console.error(erro);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

}

function atualizarAulasDepoisDaSaida(
    registro,
    horarioSaida
){

    const saida =
        horarioParaMinutos(horarioSaida);

    registro.aulas.forEach(function(aula){

        const inicio =
            horarioParaMinutos(aula.inicio);

        if(inicio >= saida){

            aula.status = "Ausente";

        }

    });

}

function mostrarCalendario(){

    const ano =
        dataCalendario.getFullYear();

    const mes =
        dataCalendario.getMonth();

    const nomesMeses = [

        "Janeiro",
        "Fevereiro",
        "Março",
        "Abril",
        "Maio",
        "Junho",
        "Julho",
        "Agosto",
        "Setembro",
        "Outubro",
        "Novembro",
        "Dezembro"

    ];

    mesAtual.innerHTML =
        nomesMeses[mes] + " " + ano;

    calendarioDias.innerHTML = "";

    const primeiroDia =
        new Date(ano, mes, 1);

    const ultimoDia =
        new Date(ano, mes + 1, 0);

    const quantidadeDias =
        ultimoDia.getDate();

    const diaSemana =
        primeiroDia.getDay();

    for(let i = 0; i < diaSemana; i++){

        const espaco =
            document.createElement("div");

        calendarioDias.appendChild(
            espaco
        );

    }

    for(let dia = 1; dia <= quantidadeDias; dia++){

        const botao =
            document.createElement("button");

        botao.innerHTML = dia;

        botao.addEventListener(
            "click",
            function(){

                selecionarDiaCalendario(
                    dia,
                    mes,
                    ano
                );

            }
        );

        calendarioDias.appendChild(
            botao
        );

    }

}

function selecionarDiaCalendario(
    dia,
    mes,
    ano
){

    const dataSelecionada =

        dia.toString().padStart(2, "0") +
        "/" +
        (mes + 1).toString().padStart(2, "0") +
        "/" +
        ano;

    tituloDiaCalendario.innerHTML =
        "📅 " + dataSelecionada;

    let presentes = 0;

    let ausentes = 0;

    alunos.forEach(function(aluno){

        const registro =
            aluno.historico.find(
                function(item){

                    return item.data ===
                        dataSelecionada;

                }
            );

        if(registro){

            if(registro.status === "Presente"){

                presentes++;

            }

            if(registro.status === "Ausente"){

                ausentes++;

            }

        }

    });

    resumoDiaCalendario.innerHTML =

        "🟢 Presentes: " +
        presentes +
        "<br><br>" +

        "🔴 Ausentes: " +
        ausentes;

}

mesAnterior.addEventListener(
    "click",
    function(){

        dataCalendario.setMonth(
            dataCalendario.getMonth() - 1
        );

        mostrarCalendario();

    }
);

mesProximo.addEventListener(
    "click",
    function(){

        dataCalendario.setMonth(
            dataCalendario.getMonth() + 1
        );

        mostrarCalendario();

    }
);

// ==============================
// CALENDÁRIO
// ==============================


function mostrarCalendario(){

    const ano = dataCalendario.getFullYear();

    const mes = dataCalendario.getMonth();

    const nomesMeses = [

        "Janeiro",
        "Fevereiro",
        "Março",
        "Abril",
        "Maio",
        "Junho",
        "Julho",
        "Agosto",
        "Setembro",
        "Outubro",
        "Novembro",
        "Dezembro"

    ];

    mesAtual.innerHTML =
        nomesMeses[mes] + " " + ano;

    calendarioDias.innerHTML = "";

    const primeiroDia =
        new Date(ano, mes, 1);

    const ultimoDia =
        new Date(ano, mes + 1, 0);

    const quantidadeDias =
        ultimoDia.getDate();

    const primeiroDiaSemana =
        primeiroDia.getDay();

    // Espaços antes do primeiro dia

    for(
        let i = 0;
        i < primeiroDiaSemana;
        i++
    ){

        const espaco =
            document.createElement("div");

        calendarioDias.appendChild(
            espaco
        );

    }

    // Cria os dias

    for(
        let dia = 1;
        dia <= quantidadeDias;
        dia++
    ){

        const botao =
            document.createElement("button");

        botao.innerHTML = dia;

        botao.addEventListener(
            "click",
            function(){

                selecionarDiaCalendario(
                    dia,
                    mes,
                    ano
                );

            }
        );

        calendarioDias.appendChild(
            botao
        );

    }

}


// ==============================
// SELECIONAR DIA
// ==============================

function selecionarDiaCalendario(
    dia,
    mes,
    ano
){

    const dataSelecionada =

        dia.toString().padStart(2, "0") +
        "/" +
        (mes + 1).toString().padStart(2, "0") +
        "/" +
        ano;

    tituloDiaCalendario.innerHTML =
        "📅 " + dataSelecionada;

    let presentes = 0;

    let ausentes = 0;

    alunos.forEach(function(aluno){

        const registro =
            aluno.historico.find(
                function(item){

                    return item.data ===
                        dataSelecionada;

                }
            );

        if(!registro){

            return;

        }

        if(registro.status === "Presente"){

            presentes++;

        }

        if(registro.status === "Ausente"){

            ausentes++;

        }

    });

    resumoDiaCalendario.innerHTML =

        "🟢 Presentes: " +
        presentes +
        "<br><br>" +

        "🔴 Ausentes: " +
        ausentes;

}


// ==============================
// MÊS ANTERIOR
// ==============================

mesAnterior.addEventListener(
    "click",
    function(){

        dataCalendario.setMonth(
            dataCalendario.getMonth() - 1
        );

        mostrarCalendario();

    }
);


// ==============================
// PRÓXIMO MÊS
// ==============================

mesProximo.addEventListener(
    "click",
    function(){

        dataCalendario.setMonth(
            dataCalendario.getMonth() + 1
        );

        mostrarCalendario();

    }
);


// ==============================
// VOLTAR
// ==============================

voltarCalendario.addEventListener(
    "click",
    function(){

        esconderTodasAsTelas();

        painel.style.display = "block";

    }
);

function carregarAlunosFrequencia(){

    alunoFrequencia.innerHTML = "";

    const opcaoInicial =
        document.createElement("option");

    opcaoInicial.value = "";

    opcaoInicial.innerHTML =
        "Selecione um aluno";

    alunoFrequencia.appendChild(
        opcaoInicial
    );

    alunos.forEach(function(aluno){

        const opcao =
            document.createElement("option");

        opcao.value = aluno.rm;

        opcao.innerHTML =
            aluno.nome +
            " - RM " +
            aluno.rm;

        alunoFrequencia.appendChild(
            opcao
        );

    });

}

function calcularFrequenciaAluno(){

    const rm =
        alunoFrequencia.value;

    const mesSelecionado =
        mesFrequencia.value;

    if(rm === ""){

        alert(
            "Selecione um aluno."
        );

        return;

    }

    if(mesSelecionado === ""){

        alert(
            "Selecione um mês."
        );

        return;

    }

    const aluno =
        alunos.find(function(a){

            return a.rm === rm;

        });

    if(!aluno){

        alert(
            "Aluno não encontrado."
        );

        return;

    }

    const registrosDoMes =
        aluno.historico.filter(
            function(registro){

                const partes =
                    registro.data.split("/");

                const mes =
                    partes[1];

                const ano =
                    partes[2];

                const mesAno =
                    ano +
                    "-" +
                    mes;

                return mesAno ===
                    mesSelecionado;

            }
        );

    let presencas = 0;

    let faltas = 0;

    registrosDoMes.forEach(
        function(registro){

            if(
                registro.status ===
                "Presente"
            ){

                presencas++;

            }

            if(
                registro.status ===
                "Ausente"
            ){

                faltas++;

            }

        }
    );

    const diasRegistrados =
        presencas + faltas;

    let porcentagem = 0;

    if(diasRegistrados > 0){

        porcentagem =
            (presencas /
            diasRegistrados) * 100;

    }

    nomeAlunoFrequencia.innerHTML =
        aluno.nome;

    totalPresencas.innerHTML =
        presencas;

    totalFaltas.innerHTML =
        faltas;

    totalDias.innerHTML =
        diasRegistrados;

    porcentagemFrequencia.innerHTML =
        porcentagem.toFixed(1) + "%";

    mostrarTabelaFrequencia(
        registrosDoMes
    );

}

function mostrarTabelaFrequencia(
    registros
){

    tabelaFrequencia.innerHTML = "";

    if(registros.length === 0){

        tabelaFrequencia.innerHTML = `

            <tr>

                <td colspan="4">

                    Nenhum registro encontrado.

                </td>

            </tr>

        `;

        return;

    }

    registros.forEach(
        function(registro){

            const linha =
                document.createElement("tr");

            let status =
                "🔴 Ausente";

            if(
                registro.status ===
                "Presente"
            ){

                status =
                    "🟢 Presente";

            }

            linha.innerHTML = `

                <td>
                    ${registro.data}
                </td>

                <td>
                    ${status}
                </td>

                <td>
                    ${registro.horario || "--:--"}
                </td>

                <td>
                    ${registro.horarioSaida || "--:--"}
                </td>

            `;

            tabelaFrequencia.appendChild(
                linha
            );

        }
    );

}

calcularFrequencia.addEventListener(
    "click",
    function(){

        calcularFrequenciaAluno();

    }
);

voltarFrequencia.addEventListener(
    "click",
    function(){

        esconderTodasAsTelas();

        painel.style.display =
            "block";

    }
);

// ==============================
// CONFIGURAÇÕES
// ==============================

async function salvarConfiguracoesSistema(){

    const configuracoes = {

        horaInicio:
            horaInicio.value,

        horaLimiteEntrada:
            horaLimiteEntrada.value,

        horaSaida:
            horaSaida.value,

        horaSaidaSemFalta:
            horaSaidaSemFalta.value

    };


    try{

        const resposta =
            await fetch(
                "http://localhost:3000/configuracoes",
                {

                    method: "PUT",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body:
                        JSON.stringify(
                            configuracoes
                        )

                }
            );


        const dados =
            await resposta.json();


        if(!resposta.ok){

            alert(
                dados.erro ||
                "Erro ao salvar configurações."
            );

            return;

        }


        alert(
            "Configurações salvas com sucesso!"
        );


    }catch(error){

        console.error(error);

        alert(
            "Não foi possível conectar ao servidor."
        );

    }

}

async function carregarConfiguracoes(){

    try{

        const resposta =
            await fetch(
                "http://localhost:3000/configuracoes"
            );


        const configuracoes =
            await resposta.json();


        if(!resposta.ok){

            console.error(
                configuracoes.erro ||
                "Erro ao carregar configurações."
            );

            return;

        }


        horaInicio.value =
            configuracoes.hora_inicio ||
            "07:30";


        horaLimiteEntrada.value =
            configuracoes.hora_limite_entrada ||
            "07:35";


        horaSaida.value =
            configuracoes.hora_saida ||
            "15:30";


        horaSaidaSemFalta.value =
            configuracoes.hora_saida_sem_falta ||
            "15:00";


    }catch(error){

        console.error(
            "Erro ao carregar configurações:",
            error
        );

    }

}

salvarConfiguracoes.addEventListener(
    "click",
    function(){

        salvarConfiguracoesSistema();

    }
);

limparConfiguracoes.addEventListener(
    "click",
    function(){

        horaInicio.value =
            "07:30";

        horaLimiteEntrada.value =
            "07:35";

        horaSaida.value =
            "15:30";

        horaSaidaSemFalta.value =
            "15:00";

    }
);

voltarConfiguracoes.addEventListener(
    "click",
    function(){

        esconderTodasAsTelas();

        painel.style.display =
            "block";

    }
);

function mostrarAulas(){

    aulasDoDia.innerHTML = "";

    aulas.forEach(function(aula){

        aulasDoDia.innerHTML += `

            <div class="cardAula">

                <h4>
                    ${aula.numero}ª Aula
                </h4>

                <p>
                    ${aula.inicio}
                    -
                    ${aula.fim}
                </p>

            </div>

        `;

    });

}